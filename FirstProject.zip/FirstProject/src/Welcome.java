import Finance.Salary;
public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to EclipseIDE");
		Bye bye = new Bye();
		bye.sayThanks();
		A a=new A();
		a.aA();
		B b=new B();
		b.bB();
		C c=new C();
		c.cC();
		Salary salary=new Salary();
		int result= salary.calculateSalary(35000, 3000);
		System.out.println("Salary is = " + result);
	}

}
