package oops;

import java.util.Scanner;

public class Employee {
	public int employeeId;
	public String employeeName;
	public String employeeAddress;
	public int salary;
	
	public void takeSalary() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter employeeId");
		employeeId= scanner.nextInt();
		System.out.println("Enter employeeName");
		employeeName= scanner.next();
		//Scanner.close();
		System.out.println("Enter employeeAddress");
		employeeAddress= scanner.next();
		//Scanner.close();
		System.out.println("Enter salary");
		salary= scanner.nextInt();
	}
	public void print() {
		System.out.println("EmployeeId : "+employeeId);
		System.out.println("EmployeeName : "+employeeName);
		System.out.println("EmployeeAddress : "+employeeAddress);
		System.out.println("Salary : "+salary);
	}
	
}
