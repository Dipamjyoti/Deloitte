package ioDemo;

import java.io.File;
import java.io.IOException;

public class Exercise {

	public static void main(String[] args) throws IOException {
		File file = new File("C:\\Deloitte\\Batch\\BatchMate.txt");
		file.createNewFile();
		System.out.println("New File created");
		//File directory=new File("C:\\JavaBrahman\\Level1");
	    File[] fileCount=file.list();
	    System.out.println("File Count:"+fileCount);

	}

}