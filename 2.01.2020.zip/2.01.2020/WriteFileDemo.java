package ioDemo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFileDemo {

	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("record2.txt");
		FileReader fr = new FileReader("record.txt");
		//File file = new File("record2.txt");
		//file.createNewFile();
		
		//fw.write("My name is Dipam");
		//fw.close();
		int i=0;
		while((i=fr.read())!=-1) {
			fw.write((char)i);
		}
		fw.close();
		fr.close();
		System.out.println("Done");

	}

}
