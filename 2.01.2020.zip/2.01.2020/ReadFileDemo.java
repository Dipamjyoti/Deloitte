package ioDemo;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileDemo {

	public static void main(String[] args) throws IOException {
		File file = new File("ram.txt");
		//file.createNewFile();
		FileReader reader = new FileReader(file);
		int i=0;
		while((i=reader.read())!=-1) {
			System.out.println((char)i);
		}
		reader.close();

	}

}
