package designPattern;

public class Payment {
	private static Payment payment = new Payment();
	private Payment() {
		System.out.println("Paymaent memory allocated");
	}
	public static Payment getPaymentObject() {
		return payment;
	}
	public void pay(int amount) {
		System.out.println("payment done for INR : "+amount);
	}
}
