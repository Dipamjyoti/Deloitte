package exceptionDemos;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo1 {
	int num1;
	int num2;
	int result;
	Scanner scanner= new Scanner(System.in);
	
	public void display() {
		System.out.println("Welcome in display");
		try {
			System.out.println("Enter 1st no. : ");
			num1 = scanner.nextInt();
			System.out.println("Enter 2nd no. : ");
			num2 = scanner.nextInt();
			result = num1 / num2;
			System.out.println("Result : " + result);
		} catch (InputMismatchException e) {
			System.out.println("Please enter numeric values only");
		}
		catch (ArithmeticException e) {
			System.out.println("Second number can't be 0");
		}		
	}
	public static void main(String[] args) {
		System.out.println("Main Started");
		Demo1 demo1 = new Demo1();
		demo1.display();
		//display();
		System.out.println("Main Ended");
	}

}
