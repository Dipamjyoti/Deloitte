
public class A {
	public void aA() {
		System.out.println("Welcome to aA");
	}
	
}
