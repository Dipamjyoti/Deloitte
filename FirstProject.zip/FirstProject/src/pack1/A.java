package pack1;

public class A {
	protected int i;
}
