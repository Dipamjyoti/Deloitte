
public class C {
	public void cC() {
		System.out.println("Welcome to cC");
	}
}
