
public class B {
	public void bB() {
		System.out.println("Welcome to bB");
	}
}
