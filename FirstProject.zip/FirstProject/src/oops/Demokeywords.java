package oops;

public class Demokeywords {
	public static void main(String[] args) {
		for (String s:args) {
			System.out.println(s);
		}
	}

}
