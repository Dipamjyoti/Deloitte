package jdbcdemos;

import java.util.Scanner;

public class Product {
	private int productId;
	private String productName;
	private int qoh;
	private int productPrice;
	
	public Product() {
		
	}
	
	public Product(int productId, String productName, int qoh, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.qoh = qoh;
		this.productPrice = price;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQoh() {
		return qoh;
	}

	public void setQoh(int qoh) {
		this.qoh = qoh;
	}

	public int getPrice() {
		return productPrice;
	}

	public void setPrice(int price) {
		this.productPrice = price;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", qoh=" + qoh + ", price=" + productPrice
				+ "]";
	}
	
	public void accept() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Product id : "); productId = scanner.nextInt();
        System.out.println("Enter Product name : "); productName = scanner.next();
        System.out.println("Enter Price : "); productPrice = scanner.nextInt();
        System.out.println("Enter Quantity on Hand : "); qoh = scanner.nextInt();
    }
}
