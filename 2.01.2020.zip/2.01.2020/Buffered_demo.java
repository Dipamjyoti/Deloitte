package ioDemo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Buffered_demo {

	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("record2.txt");
		FileReader fr = new FileReader("record.txt");
		//File file = new File("record2.txt");
		//file.createNewFile();
		
		//fw.write("My name is Dipam");
		//fw.close();
		BufferedReader bufferedReader= new BufferedReader(new FileReader(new File("ram.txt")));
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File("sharma.txt")));
		
		int i=0;
		while((i=bufferedReader.read())!=-1) {
			bufferedWriter.write((char)i);
		}
		bufferedReader.close();
		bufferedWriter.close();
		System.out.println("Done");

	}

}
