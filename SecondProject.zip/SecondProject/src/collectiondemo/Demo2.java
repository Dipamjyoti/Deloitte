package collectiondemo;

import java.util.LinkedHashSet;
import java.util.Set;

public class Demo2 {

	public static void main(String[] args) {
		Set names = new LinkedHashSet();
		names.add("Jay");
		names.add("Veeru");
		names.add("Neha");
		names.add("Spring");
		
		names.remove("Neha");
		System.out.println(names);

	}

}
