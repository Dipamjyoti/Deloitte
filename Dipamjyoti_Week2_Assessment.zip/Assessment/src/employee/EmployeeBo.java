package employee;

public class EmployeeBo {

	public void calincomeTax(EmployeeVo e) {
		
		double a=e.getAnnualIncome();
		if(a<300000) {
			e.setIncomeTax(0);
		}
		else if(a<600000)
		{
			e.setIncomeTax(0.05*a);
		}
		else
		{
			e.setIncomeTax(0.08*a);
		}
		
		
	}
}

