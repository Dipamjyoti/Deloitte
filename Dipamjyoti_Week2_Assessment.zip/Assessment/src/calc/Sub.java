package calc;

public class Sub extends Arithmetic {
	@Override
	public int calc(int x, int y) {
		return x-y;
	}

}

