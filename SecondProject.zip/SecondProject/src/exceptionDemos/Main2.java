package exceptionDemos;

public class Main2 {

	public static void main(String[] args) {
		Product product = new Product(11, "Computer", 50, 100000);
		System.out.println(product);

	}

}
