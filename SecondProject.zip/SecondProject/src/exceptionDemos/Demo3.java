package exceptionDemos;

import java.util.Scanner;

class InvalidAgeException extends Exception
{
	public InvalidAgeException() {
		
	}
	
	public InvalidAgeException(String msg) {
		super(msg);
	}
}

class NewYearParty{
	int eligibleAge=16;
	Scanner scanner = new Scanner(System.in);
	int age;
	public void enterClub() throws InvalidAgeException {
		System.out.println("Please enter your age : ");
		age = scanner.nextInt();
		if(age<eligibleAge) {
			throw new InvalidAgeException("Under age");
		}
		else
			System.out.println("Welcome");
		System.out.println("Enter");
	}
}
public class Demo3 {

	public static void main(String[] args) {
		NewYearParty party = new NewYearParty();
		try {
			party.enterClub();
		} catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Enjoy");
	}

}
