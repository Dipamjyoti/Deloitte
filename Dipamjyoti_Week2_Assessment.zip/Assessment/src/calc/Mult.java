package calc;


public class Mult extends Arithmetic {
	@Override
	public int calc(int x, int y) {
		return x*y;
	}

}
