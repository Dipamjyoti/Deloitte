//local and instance variable
package Demo;

public class Demo1 {
	int i;
	int num=10;
	public void display() {
		int j=20;
		if(num==10)
			j=20;
		System.out.println((i=num)-j);
	}
	public static void main(String[] args) {
		Demo1 demo1=new Demo1();
		demo1.display();
	}
}
