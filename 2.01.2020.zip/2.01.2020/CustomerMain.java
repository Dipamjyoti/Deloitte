package collectiondemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import exceptionDemos.Customer;

public class CustomerMain {

	public static void main(String[] args) {
		List<Customer>allCustomers=new ArrayList<Customer>();
		
		Customer customer1 = new Customer(101, "Jaya", "Pune", 98000);
		
		allCustomers.add(customer1);
		allCustomers.add(new Customer(102, "Pooja", "Delhi", 65000));
		allCustomers.add(new Customer(103, "Tarun", "Mumbai", 1000));
		allCustomers.add(new Customer(104, "Harish", "Jaipur", 2000));
		allCustomers.add(new Customer(105, "Ahmed", "Bangalore", 20000));
		
		System.out.println(allCustomers);
		
		/*Iterator<Customer> customerIterator= allCustomers.iterator();
		
		while(customerIterator.hasNext()) {
			Customer customer=customerIterator.next();
			System.out.println(customer);
		}*/
		
		System.out.println(""
				+ "------------------------------------------------------------------------------------------------"
				+ "");
		System.out.println("Sort on 1) Name 2)Address 3) BillAmount");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		
		//sorting
		
		if(choice==3) {
			Collections.sort(allCustomers);
			System.out.println("After sorting on bill Amount: ");
			System.out.println(allCustomers);
		}
		
		if(choice==1) {
			Collections.sort(allCustomers, new NameComparator());
			System.out.println("After sorting on Name: ");
			System.out.println(allCustomers);
		}
		if(choice==2) {
			Collections.sort(allCustomers,new Comparator<Customer>() {

				@Override
				public int compare(Customer o1, Customer o2) {
					if (o1.getCustomerAddress().compareTo(o2.getCustomerAddress())>0) {
						return 0;
					} else {
						return -1;
					}
				}
				
			});
			System.out.println("After sorting on Address: ");
			System.out.println(allCustomers);
		}
		
		/*Iterator<Customer> customerIterator1= allCustomers.iterator();
		
		while(customerIterator1.hasNext()) {
			Customer customer=customerIterator1.next();
			System.out.println(customer);
		}*/
	}

}
