package com;

public class ContactDetails {
	private long mobileNumber;
	private String emailId;
	
	public ContactDetails() {
		
	}

	public ContactDetails(long mobileNumber, String emailId) {
		super();
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "ContactDetails [mobileNumber=" + mobileNumber + ", emailId=" + emailId + "]";
	}

	
	
	
}
