package jdbcdemos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Update2 {

	public static void main(String[] args) throws SQLException {
		Product product = new Product();
		product.accept();
		
		Connection connection = DBConnection.makeConnection();
		PreparedStatement statement = connection.prepareStatement("update hr.product set ProductName=?,ProductPrice=?,Qoh=?where ProductId=?");
		
		statement.setString(1, product.getProductName());
		statement.setInt(2, product.getPrice());
		statement.setInt(3, product.getQoh());
		statement.setInt(4, product.getProductId());
		
		statement.executeUpdate();
		System.out.println("Data successfully entered in productID : "+product.getProductId());
	}

}
