package ioDemo;

import java.io.File;
import java.io.IOException;

public class Demo1 {

	public static void main(String[] args) throws IOException {
		File file=new File("c:\\Deloitte\\K\\T\\K\\newyear.txt");
		File h=new File("c:\\Deloitte\\K\\T\\K");
		
		if(file.exists()) {
			System.out.println("File present");
			file.delete();
		}
		else {
			h.mkdirs();
			file.createNewFile();
			System.out.println("New File created");
		}
		System.out.println("Done");
		
	}

}
