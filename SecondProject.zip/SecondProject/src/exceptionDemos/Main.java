package exceptionDemos;

public class Main {

	public static void main(String[] args) {
		Customer customer = new Customer(9651,"Geetanjali","Thrissur",97000);
				System.out.println(customer);
				customer.setBillAmount(12000);
				System.out.println(customer);
	}

}
