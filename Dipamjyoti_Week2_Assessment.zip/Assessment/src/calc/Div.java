package calc;


public class Div extends Arithmetic {
	@Override
	public int calc(int x, int y) {
		return (int)x/y;
	}

}

