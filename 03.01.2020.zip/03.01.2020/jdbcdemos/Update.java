package jdbcdemos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Update {

	public static void main(String[] args) throws SQLException {
		Customer customer = new Customer();
		customer.accept();
		
		Connection connection = DBConnection.makeConnection();
		PreparedStatement statement = connection.prepareStatement("update hr.customer set CustomerName=?,CustomerAddress=?,BillAmount=?CustomerId=?");
		
		statement.setString(1, customer.getCustomerName());
		statement.setString(2, customer.getCustomerAddress());
		statement.setInt(3, customer.getBillAmount());
		statement.setInt(4, customer.getCustomerId());
		
		statement.executeUpdate();
		System.out.println("Data successfully entered in customerID : "+customer.getCustomerId());
	}

}
