package Finance;

public class Salary {
	public int calculateSalary(int basic,int pf) {
		return basic+pf;
	}

}
