package exceptionDemos;

public class Demo2 {
	
	public void display1() throws InterruptedException {
		System.out.println("Welcome in display1");
		Thread.sleep(1000);
		System.out.println("Exit from display1");
	}
	
	public void display2() throws InterruptedException{
		System.out.println("Welcome in display2");
		Thread.sleep(1000);
		System.out.println("Exit from display2");
	}
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Main Started");
		Demo2 demo2 = new Demo2();
		demo2.display1();
		demo2.display2();
		System.out.println("Main Ended");

	}

}
