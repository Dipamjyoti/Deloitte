package collectiondemo;

import java.util.ArrayList;
import java.util.List;

public class Demo1 {

	public static void main(String[] args) {
		List names = new ArrayList();
		names.add("Himanshu");
		names.add("Anthony");
		names.add("Swami");
		names.add("Swami");
		
		System.out.println(names);
		names.add(2,"Reddy");
		System.out.println(names);
		names.remove("Swami");
		System.out.println(names.isEmpty());
		System.out.println(names.size());
	}

}
